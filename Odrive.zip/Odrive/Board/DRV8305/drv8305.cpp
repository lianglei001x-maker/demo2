
#include "drv8305.hpp"

#include "utils.hpp"
#include "cmsis_os.h"
#include "board.h"

const SPI_InitTypeDef Drv8301::spi_config_ = {
    .Mode = SPI_MODE_MASTER,
    .Direction = SPI_DIRECTION_2LINES,
    .DataSize = SPI_DATASIZE_16BIT,
    .CLKPolarity = SPI_POLARITY_LOW,
    .CLKPhase = SPI_PHASE_2EDGE,
    .NSS = SPI_NSS_SOFT,
    .BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16,
    .FirstBit = SPI_FIRSTBIT_MSB,
    .TIMode = SPI_TIMODE_DISABLE,
    .CRCCalculation = SPI_CRCCALCULATION_DISABLE,
    .CRCPolynomial = 10,
};
/**
 * @brief 配置Drv8305 的控制寄存器
 * 
 * @param requested_gain 
 * @param actual_gain 
 * @return true 
 * @return false 
 */

bool Drv8305::config() {

    RegisterFile new_config;

    new_config.control_register_1 =
        (0b11 << 8)            // High-side gate driver peak source time=1780ns
        | (0b1010 << 4)        // High-side gate driver peak sink current = 1A
        | (0b1010 << 0);       // High-side gate driver peak source current = 0.75A

    new_config.control_register_2 =
        (0b11 << 8)            // Low-side gate driver peak source time=1780ns
        | (0b1010 << 4)        // Low-side gate driver peak sink current = 1A
        | (0b1010 << 0);       // Low-side gate driver peak source current = 0.75A

    new_config.control_register_3 =
        (0b1 << 9)             // Rectification control (PWM_MODE = b'10 only)
        | (0b00 << 4)          // PWM with 6 independent inputs
        | (0b011 << 4)          // Dead time = 440ns
        | (0b01 << 2)          // VDS sense blanking = 1.75us
        | (0b01 << 0);         // VDS sense deglitch = 1.75us

    new_config.control_register_4 =
        (0b00000010101 );             // Gain of CS amplifier 1 2 3 =20


    new_config.control_register_5 =
        (0b00100001010 );             // Gain of CS amplifier 1 2 3 =20

    new_config.control_register_6 =
        (0b00100001010 );

    new_config.control_register_7 =
        (0b00011001000 );


    bool regs_equal = (regs_.control_register_1 == new_config.control_register_1)
                   && (regs_.control_register_2 == new_config.control_register_2)
				   && (regs_.control_register_3 == new_config.control_register_3)
				   && (regs_.control_register_4 == new_config.control_register_4)
				   && (regs_.control_register_5 == new_config.control_register_5)
				   && (regs_.control_register_6 == new_config.control_register_6)
				   && (regs_.control_register_7 == new_config.control_register_7);

    if (!regs_equal) {                 //如果新配置的和之前的不同
        regs_ = new_config;            //将配置值给drv8301的寄存器
        state_ = kStateUninitialized;
        enable_gpio_.write(false);     //使能信号无效
    }

    return true;                      //返回1
}

bool Drv8305::init() {
    uint16_t val;

    if (state_ == kStateReady) {
        return true;
    }

    // Reset DRV chip. The enable pin also controls the SPI interface, not only
    // the driver stages.
    enable_gpio_.write(false);
    delay_us(40); // mimumum pull-down time for full reset: 20us
    state_ = kStateUninitialized; // make is_ready() ignore transient errors before registers are set up
    enable_gpio_.write(true);
    osDelay(20); // t_spi_ready, max = 10ms

    // Write current configuration
    bool wrote_regs = write_reg(kRegNameControl1, regs_.control_register_1)
                       && write_reg(kRegNameControl2, regs_.control_register_2)
                       && write_reg(kRegNameControl3, regs_.control_register_3)
                       && write_reg(kRegNameControl4, regs_.control_register_4)
                       && write_reg(kRegNameControl5, regs_.control_register_5) // the write operation tends to be ignored if only done once (not sure why)
                       && write_reg(kRegNameControl6, regs_.control_register_6)
					   && write_reg(kRegNameControl7, regs_.control_register_7);


    if (!wrote_regs) {
        return false;       //如果写错误，返回false
    }

    // Wait for configuration to be applied
    delay_us(100);
    state_ = kStateStartupChecks;

    bool is_read_regs = read_reg(kRegNameControl1, &val) && (val == regs_.control_register_1)
                      && read_reg(kRegNameControl2, &val) && (val == regs_.control_register_2)
					  && read_reg(kRegNameControl3, &val) && (val == regs_.control_register_3)
					  && read_reg(kRegNameControl4, &val) && (val == regs_.control_register_4)
					  && read_reg(kRegNameControl5, &val) && (val == regs_.control_register_5)
					  && read_reg(kRegNameControl6, &val) && (val == regs_.control_register_6)
					  && read_reg(kRegNameControl7, &val) && (val == regs_.control_register_7);


    if (!is_read_regs) {
        return false;
    }

    if (get_error() != FaultType_NoFault) {
        return false;
    }

    // There could have been an nFAULT edge meanwhile. In this case we shouldn't
    // consider the driver ready.
    CRITICAL_SECTION() {
        if (state_ == kStateStartupChecks) {
            state_ = kStateReady;
        }
    }

    return state_ == kStateReady;
}

void Drv8305::do_checks() {
    if (state_ != kStateUninitialized && !nfault_gpio_.read()) {      //如果不是未初始化状态并且nfault引脚为0（没有错误）
        state_ = kStateUninitialized;
    }
}

bool Drv8305::is_ready() {
    return state_ == kStateReady;
}

bool Drv8305::get_error() {
    uint16_t fault1, fault2, fault3, fault4;

    if (!read_reg(kRegNameStatus1, &fault1) ||        //如果读取错误
        !read_reg(kRegNameStatus2, &fault2) ||
		!read_reg(kRegNameStatus3, &fault3) ||
		!read_reg(kRegNameStatus4, &fault4)) {
        return (FaultType_e)0xffffffff;               //返回1
    }

    return (fault1 == 0)&(fault2 == 0)&(fault3 == 0)&(fault4 == 0);
}

bool Drv8305::read_reg(const RegName_e regName, uint16_t* data) {
    tx_buf_ = build_ctrl_word(DRV8305_CtrlMode_Read, regName, 0);
    if (!spi_arbiter_->transfer(spi_config_, ncs_gpio_, (uint8_t *)(&tx_buf_), nullptr, 1, 1000)) {
        return false;
    }
    
    delay_us(1);

    tx_buf_ = build_ctrl_word(DRV8305_CtrlMode_Read, regName, 0);
    rx_buf_ = 0xffff;
    if (!spi_arbiter_->transfer(spi_config_, ncs_gpio_, (uint8_t *)(&tx_buf_), (uint8_t *)(&rx_buf_), 1, 1000)) {
        return false;
    }

    delay_us(1);

    if (rx_buf_ == 0xbeef) {
        return false;
    }

    if (data) {
        *data = rx_buf_ & 0x07FF;
    }
    
    return true;
}

bool Drv8305::write_reg(const RegName_e regName, const uint16_t data) {
    // Do blocking write
    tx_buf_ = build_ctrl_word(DRV8301_CtrlMode_Write, regName, data);
    if (!spi_arbiter_->transfer(spi_config_, ncs_gpio_, (uint8_t *)(&tx_buf_), nullptr, 1, 1000)) {
        return false;
    }
    delay_us(1);

    return true;
}
