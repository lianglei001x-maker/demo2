#ifndef __DRV8305_HPP
#define __DRV8305_HPP

#include "stdbool.h"
#include "stdint.h"

#include <Board/gate_driver.hpp>
#include <Board/STM32/stm32_spi_arbiter.hpp>
#include <Board/STM32/stm32_gpio.hpp>

/**
 * @brief 驱动器Drv8301类，构造函数参数有spi通信口、片选端、使能端口、错误端口
 * 
 */
class Drv8305 : public GateDriverBase, public OpAmpBase {
public:
     enum Warning {

        // Status Register 1 address(0x1)
        WarningType_OTW         = (1 << 0),  //!< Overtemperature warning
        WarningType_TEMP_FLAG3  = (1 << 1),  //!< Temperature flag setting for approximately 135°C
		WarningType_TEMP_FLAG2  = (1 << 2),  //!< Temperature flag setting for approximately 125°C
		WarningType_TEMP_FLAG1  = (1 << 3),  //!< Temperature flag setting for approximately 105°C
		WarningType_VCHP_UVFL   = (1 << 4),  //!< Charge pump undervoltage flag warning
		WarningType_VDS_STATUS  = (1 << 5),  //!< Real time OR of all VDS overcurrent monitors
		WarningType_PVDD_OVFL   = (1 << 6),  //!< PVDD overvoltage flag warning
		WarningType_PVDD_UVFL   = (1 << 7),  //!< PVDD undervoltage flag warning
		WarningType_TEMP_FLAG4  = (1 << 8),  //!< Temperature flag setting for approximately 175°C
		WarningType_RSVD        = (1 << 9),  //!< Fault indication
		WarningType_FAULT       = (1 << 10),

    };                //告警消息，见datasheet 7.6.1.1

     enum OV_Faults {

    	 FaultType_SNS_A_OCP = (1 << 0),     //Sense A overcurrent fault
		 FaultType_SNS_B_OCP = (1 << 1),     //Sense B overcurrent fault
		 FaultType_SNS_C_OCP = (1 << 2),     //Sense C overcurrent fault
		 FaultType_VDS_LC    = (1 << 5),
		 FaultType_VDS_HC    = (1 << 6),
		 FaultType_VDS_LB    = (1 << 7),
		 FaultType_VDS_HB    = (1 << 8),
		 FaultType_VDS_LA    = (1 << 9),
		 FaultType_VDS_HA    = (1 << 10),
     };

     enum IC_Faults{

    	 FaultType_VCPH_OVLO_ABS = (1 << 0),
		 FaultType_VCPH_OVLO     = (1 << 1),
		 FaultType_VCPH_UVLO2    = (1 << 2),
		 FaultType_VCP_LSD_UVLO2 = (1 << 4),
		 FaultType_AVDD_UVLO     = (1 << 5),
		 FaultType_VREG_UV       = (1 << 6),
		 FaultType_OTSD          = (1 << 8),
		 FaultType_WD_FAULT      = (1 << 9),
		 FaultType_PVDD_UVLO2    = (1 << 10),
     };

     enum VGS_Faults{

    	 FaultType_VGS_LC  = (1 << 5),
		 FaultType_VGS_HC  = (1 << 6),
		 FaultType_VGS_LB  = (1 << 7),
		 FaultType_VGS_HB  = (1 << 8),
		 FaultType_VGS_LA  = (1 << 9),
		 FaultType_VGS_HA  = (1 << 10),
     };

    Drv8305(Stm32SpiArbiter* spi_arbiter, Stm32Gpio ncs_gpio,
            Stm32Gpio enable_gpio, Stm32Gpio nfault_gpio)
            : spi_arbiter_(spi_arbiter), ncs_gpio_(ncs_gpio),
              enable_gpio_(enable_gpio), nfault_gpio_(nfault_gpio) {}      //构造函数

    /**
     * @brief Prepares the gate driver's configuration.
     *
     * If the gate driver was in ready state and the new configuration is
     * different from the old one then the gate driver will exit ready state.
     *
     * In any case changes to the configuration only take effect with a call to
     * init().
     */
    bool config(float requested_gain, float* actual_gain);
    
    /**
     * @brief Initializes the gate driver to the configuration prepared with
     * config().
     *
     * Returns true on success or false otherwise (e.g. if the gate driver is
     * not connected or not powered or if config() was not yet called).
     */
    bool init();

    /**
     * @brief Monitors the nFAULT pin.
     *
     * This must be run at an interval of <8ms from the moment the init()
     * functions starts to run, otherwise it's possible that a temporary power
     * loss is missed, leading to unwanted register values.
     * In case of power loss the nFAULT pin can be low for as little as 8ms.
     */
    void do_checks();

    /**
     * @brief Returns true if and only if the DRV8301 chip is in an initialized
     * state and ready to do switching and current sensor opamp operation.
     */
    bool is_ready() final;

    /**
     * @brief This has no effect on this driver chip because the drive stages are
     * always enabled while the chip is initialized
     */
    bool set_enabled(bool enabled) final { return true; }

    bool get_error();

    float get_midpoint() final {
        return 0.5f; // [V]
    }

    float get_max_output_swing() final {
        return 1.35f / 1.65f; // +-1.35V, normalized from a scale of +-1.65V to +-0.5
    }

private:
    enum CtrlMode_e {
        DRV8305_CtrlMode_Read = 1 << 15,   //!< Read Mode
        DRV8305_CtrlMode_Write = 0 << 15   //!< Write Mode
    };

    enum RegName_e {
        kRegNameStatus1  = 1 << 11,  //!< Status Register 1
        kRegNameStatus2  = 2 << 11,  //!< Status Register 2
		kRegNameStatus3  = 3 << 11,  //!< Status Register 3
		kRegNameStatus4  = 4 << 11,  //!< Status Register 4
        kRegNameControl1 = 5 << 11,  //!< Control Register 1
        kRegNameControl2 = 6 << 11,   //!< Control Register 2
		kRegNameControl3 = 7 << 11,   //!< Control Register 3
		kRegNameControl4 = 9 << 11,   //!< Control Register 4
		kRegNameControl5 = 0xA << 11,   //!< Control Register 5
		kRegNameControl6 = 0xB << 11,   //!< Control Register 6
		kRegNameControl6 = 0xC << 11,   //!< Control Register 7
    };

    struct RegisterFile {
        uint16_t control_register_1;
        uint16_t control_register_2;
        uint16_t control_register_3;
        uint16_t control_register_4;
        uint16_t control_register_5;
        uint16_t control_register_6;
        uint16_t control_register_7;
    };

    static inline uint16_t build_ctrl_word(const CtrlMode_e ctrlMode,
                                           const RegName_e regName,
                                           const uint16_t data) {
        return ctrlMode | regName | (data & 0x07FF);
    }

    /** @brief Reads data from a DRV8301 register */
    bool read_reg(const RegName_e regName, uint16_t* data);

    /** @brief Writes data to a DRV8301 register. There is no check if the write succeeded. */
    bool write_reg(const RegName_e regName, const uint16_t data);

    static const SPI_InitTypeDef spi_config_;

    // Configuration
    Stm32SpiArbiter* spi_arbiter_;
    Stm32Gpio ncs_gpio_;
    Stm32Gpio enable_gpio_;
    Stm32Gpio nfault_gpio_;

    RegisterFile regs_; //!< Current configuration. If is_ready_ is
                        //!< true then this can be considered consistent
                        //!< with the actual file on the DRV8301 chip.

    // We don't put these buffers on the stack because we place the stack in
    // a RAM section which cannot be used by DMA.
    uint16_t tx_buf_, rx_buf_;

    enum {
        kStateUninitialized,
        kStateStartupChecks,
        kStateReady,
    } state_ = kStateUninitialized;
};


#endif // __DRV8305_HPP
