
#include "stm32_system.h"

uint32_t irq_counters[254]; // 14 core interrupts, 240 NVIC interrupts
