#ifndef __ODRIVE_CAN_HPP
#define __ODRIVE_CAN_HPP

#include <cmsis_os.h>

#include "canbus.hpp"
#include "can_simple.hpp"
#include <autogen/interfaces.hpp>

#define CAN_CLK_HZ (42000000)
#define CAN_CLK_MHZ (42)

// Anonymous enum for defining the most common CAN baud rates 
// can 常用的通信速率
enum {
    CAN_BAUD_125K = 125000,
    CAN_BAUD_250K = 250000,
    CAN_BAUD_500K = 500000,
    CAN_BAUD_1000K = 1000000,
    CAN_BAUD_1M = 1000000
};

class ODriveCAN : public CanBusBase, public ODriveIntf::CanIntf {
public:
    struct Config_t {                                 //CAN设置结构
        uint32_t baud_rate = CAN_BAUD_250K;
        Protocol protocol = PROTOCOL_SIMPLE;           //初始化为简单协议

        ODriveCAN* parent = nullptr; // set in apply_config()
        void set_baud_rate(uint32_t value) { parent->set_baud_rate(value); }
    };

    ODriveCAN() {}                                      //构造函数

    bool apply_config();                               //应用配置
    bool start_server(CAN_HandleTypeDef* handle);      //启动服务

    Error error_ = ERROR_NONE;

    Config_t config_;
    CANSimple can_simple_{this};

    osThreadId thread_id_;                                 //指针，指向线程控制器                           
    const uint32_t stack_size_ = 1024;  // Bytes          //堆栈大小

private:
    static const uint8_t kCanFifoNone = 0xff;            //常数，表示不在can序列里

    struct ODriveCanSubscription : CanSubscription {         //Odrivecan订阅结构体，继承自can订阅结构体
        uint8_t fifo = kCanFifoNone;                         //队列
        on_can_message_cb_t callback;                        //回调函数指针
        void* ctx;                                           //指针？？
    };

    bool reinit();                                            //初始化
    void can_server_thread();                                 
    bool set_baud_rate(uint32_t baud_rate);                   //设置波特率
    void process_rx_fifo(uint32_t fifo);                      //处理缓存器中的信息
    bool send_message(const can_Message_t& message) final;       //
    bool subscribe(const MsgIdFilterSpecs& filter, on_can_message_cb_t callback, void* ctx, CanSubscription** handle) final;
    bool unsubscribe(CanSubscription* handle) final;

    // Hardware supports at most 28 filters unless we do optimizations. For now
    // we don't need that many.
    std::array<ODriveCanSubscription, 8> subscriptions_;            //subscriptions_为订阅数组，大小为8
    CAN_HandleTypeDef *handle_ = nullptr;            //can操作指针
};

#endif  // __ODRIVE_CAN_HPP
