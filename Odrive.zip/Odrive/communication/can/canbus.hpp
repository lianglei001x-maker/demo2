#ifndef __CANBUS_HPP
#define __CANBUS_HPP

#include "can_helpers.hpp"
#include <variant>

struct MsgIdFilterSpecs {                                    //ID 滤波结构体
    std::variant<uint16_t, uint32_t> id;                     //CAN 地址，支持两种类型16位和32位
    uint32_t mask;                                           //CAN 地址掩码
};

//can总线基础类
class CanBusBase {                                                                    
public:
    typedef void(*on_can_message_cb_t)(void* ctx, const can_Message_t& message);      //定义一种以最后括号内为参数，返回值为void*的函数指针
    struct CanSubscription {};                                                          //CAN 订阅结构体

    /**
     * @brief Sends the specified CAN message.
     * 
     * @returns: true on success or false otherwise (e.g. if the send queue is
     * full).
     */
    virtual bool send_message(const can_Message_t& message) = 0;                     //发送消息

    /**
     * @brief Registers a callback that will be invoked for every incoming CAN
     * message that matches the filter. 将消息和对应的回调函数对应
     * 
     * @param handle: On success this handle is set to an opaque pointer that
     *        can be used to cancel the subscription.
     * 
     * @returns: true on success or false otherwise (e.g. if the maximum number
     * of subscriptions has been reached).
     */
    virtual bool subscribe(const MsgIdFilterSpecs& filter, on_can_message_cb_t callback, void* ctx, CanSubscription** handle) = 0;

    /**
     * @brief Deregisters a callback that was previously registered with subscribe().
     */
    virtual bool unsubscribe(CanSubscription* handle) = 0;
};

#endif // __CANBUS_HPP